﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GadeProject
{
    internal class Map
    {
        string[,] map;

         //The game runs but I have no idea how to fix this error//
            private int enemyNum;
            public Hero PLAYER;

            public Hero GetHero()
            {
                return PLAYER;
            }
            private Tile[,] mapcontainer;
            public Tile[,] MAPCONTAINER
            {
                get { return mapcontainer; }
                set { mapcontainer = value; }
            }
            //private Hero playercharacter;
            //public Hero PLAYERCHARCTER
            // {
            //   get { return playercharacter; }
            //    set { playercharacter = value; }
            //}
            public void UpdateVision()
            {
                for (int setvision = 0; setvision < enemies.Count; setvision++)
                {

    }
}
