﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GadeProject
{
    public abstract class Enemy : Character 
    {
        protected Random num = new Random();

        public Enemy(int x, int y, int Damage,TileType type, int Hp, int maxHp, string symbol) : base (x, y, type)
        {

        }
        protected int Hp { set; get; }
        protected int maxHp { set; get; }
        protected int Damage { set; get; }

        public override string ToString()
        {
            return Type.ToString() + " at " + "[" + x.ToString() + "," + y.ToString() + "] (Damage: " + Damage.ToString() + ")";
        }

    }
}
