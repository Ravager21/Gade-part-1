﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GadeProject
{
    internal class Hero : Character
    {
        public Hero(int x, int y, int Hp, int maxHp) : base (x, y, TileType.Hero)
        {
            Damage = 2;
        }

        public override Movement ReturnMove(Movement HeroMove)
        {
            if (HeroMove == Movement.Up)
            {
                if ((!(this.Vision[0] is Character)) && (!(this.Vision[0] is Obstacle)))
                {
                    return Movement.Up;
                }

            }
            if (HeroMove == Movement.Down)
            {
                if ((!(this.Vision[1] is Character)) && (!(this.Vision[1] is Obstacle)))
                {
                    return Movement.Down;
                }
            }

            if (HeroMove == Movement.Left)
            {
                if ((!(this.Vision[2] is Character)) && (!(this.Vision[2] is Obstacle)))
                {
                    return Movement.Left;
                }
            }

            if (HeroMove == Movement.Right)
            {
                if ((!(this.Vision[3] is Character)) && (!(this.Vision[3] is Obstacle)))
                {
                    return Movement.Right;
                }
            }
            return Movement.NoMovement;
        }
        public override string ToString()
        {
            return "Player stats: \n" + "HP: " + Hp.ToString() + "\n Damage: " + Damage.ToString() 
                + "[" + x.ToString() + "," + y.ToString() + "]";   
        }

    }
}
