﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GadeProject
{
    public abstract class Character : Tile
    {
        int PlayerDamage = 2;

        protected Character(int x, int y, TileType type) : base(x, y, type)
        {

        }

        protected int Hp { set; get; }
        protected int maxHp {set; get;}
        protected int Damage { set; get; }

        string[] TileArray = { "North", "South", "East", "West" };
        double[] visions = new double[4];

        public enum Movement
        {
            NoMovement,
            Up,
            Down,
            Right,
            Left

        }

        public virtual void Attack(Character Target) // idk why theres an error
        {
           Target.Hp  -= PlayerDamage;
        }

        public bool IsDead()
        {
            if(Hp <= 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

       public virtual bool CheckRange(int CharacterTarget)
        {
            

            if(CharacterTarget == 1)
            {
                return true;
            }


            else
            {
                return false;
            }
        }
        
        public void Move(Movement move)
        {
            if(move == Movement.NoMovement)
            {
                this.x = 0;
            }
            else if(move == Movement.Up)
            {
                this.x++;
            }
            else if (move == Movement.Down)
            {
                this.x--;
            }
            else if(move == Movement.Right)
            {
                this.y++;
            }
            else if(move == Movement.Left)
            {
                this.y--;
            }
        }
        public abstract Movement ReturnMove(Movement move);


        protected List<Tile> vision = new List<Tile>();

        public List<Tile> Vision
        {
            get { return vision; }
            set { vision = value; }
        }
        
        public void setVision(Tile[,] Sight) // remeber to dicussed how big the map is.
        {
            Vision.Clear();

            Vision.Add(Sight[x - 1, y]);
            Vision.Add(Sight[x + 1, y]);
            Vision.Add(Sight[x, y - 1]);
            Vision.Add(Sight[x, y + 1]);
        }

        public override string ToString()
        {
            return base.ToString();
        }


    }
}

