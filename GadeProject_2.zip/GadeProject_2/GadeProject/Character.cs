﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GadeProject
{
    public abstract class Character : Tile
    {
        int PlayerDamage = 2;

        protected Character(int x, int y, TileType type) : base(x, y, type)
        {

        }

        protected int Hp { set; get; }
        protected int maxHp {set; get;}
        protected int Damage { set; get; }
        

        string[] TileArray = { "North", "South", "East", "West" };
        double[] visions = new double[4];

        public enum MovementEnum
        {
            NoMovement,
            Up,
            Down,
            Right,
            Left

        }

        public virtual void Attack(Character Target) 
        {
           Target.Hp  -= PlayerDamage;
        }

        public bool IsDead()
        {
            if(Hp <= 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

       public virtual bool CheckRange(int CharacterTarget)
        {
            

            if(CharacterTarget == 1)
            {
                return true;
            }


            else
            {
                return false;
            }
        }

        private int DistanceTo()
        {
            return 2;
        }
        
        public void Move(MovementEnum move)
        {
            if(move == MovementEnum.NoMovement)
            {
                this.x = x;
                this.y = y;
            }
            else if(move == MovementEnum.Up)
            {
                this.x++;
            }
            else if (move == MovementEnum.Down)
            {
                this.x--;
            }
            else if(move == MovementEnum.Right)
            {
                this.y++;
            }
            else if(move == MovementEnum.Left)
            {
                this.y--;
            }
        }
        public abstract MovementEnum ReturnMove(MovementEnum move);


        protected List<Tile> vision = new List<Tile>();

        public List<Tile> Vision
        {
            get { return vision; }
            set { vision = value; }
        }
        
        public void setVision(Tile[,] Sight) 
        {
            Vision.Clear();

            Vision.Add(Sight[x - 1, y]);
            Vision.Add(Sight[x + 1, y]);
            Vision.Add(Sight[x, y - 1]);
            Vision.Add(Sight[x, y + 1]);
        }

        public override string ToString()
        {
            return base.ToString();
        }


    }
}

