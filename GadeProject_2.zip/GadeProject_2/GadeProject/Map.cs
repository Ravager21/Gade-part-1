﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GadeProject
{
    internal class Map
    {


        int[] Enemies;
        public Hero PLAYER;


        public Tile[,] mapContainer;
        public int mapWidth { get; set; }
        public int mapHeight { get; set; }

        Random number = new Random();
        public Enemy placement;
        public Enemy getEnemy()
        {
            return placement;
        }
        public Hero Player;

        public Hero getHero()
        {
            return Player;
        }


        public Map(int minWidth, int maxWidth, int minHeight, int maxHeight, int NumOfEnemies)
        {
            mapWidth = number.Next(minWidth, maxWidth);

            mapHeight = number.Next(minHeight, maxHeight);

            mapContainer = new Tile[mapWidth, mapHeight];

            Enemies = new int[NumOfEnemies];

            Create(Character.TileType.Hero, number.Next(2, mapWidth) - 1, number.Next(2, mapHeight) - 1);

            for (int i = 0; i < Enemies.Length; i++)
            {
                Create(Character.TileType.Enemy, number.Next(2, mapWidth) - 1, number.Next(2, mapHeight) - 1);
            }

        }

        

        private Tile Create(Character.TileType Type, int x, int y)
        {
            if (Type == Tile.TileType.Hero)
            {
                Player = new Hero(x, y, "H", 10, 10);
                mapContainer[x, y] = Player;

            }
            else if (Type == Tile.TileType.Enemy)
            {
                SwampCreatures newEnemy = new SwampCreatures(x, y);
                mapContainer[x, y] = newEnemy;

            }
            return mapContainer[x, y];

        }
        public void UpdateVision()
        {
            for (int i = 0; i < Enemies.Length; i++)
            {
                placement.setVision(mapContainer);
            }
            Player.setVision(mapContainer);
        }



        public Hero GetHero()
        {
            return PLAYER;
        }

        public Tile[,] MAPS
        {
            get { return mapContainer; }
            set { mapContainer = value; }
        }

        internal void TryMove(Character.MovementEnum controls)
        {
            throw new NotImplementedException();
        }

       

        
    }
}
