﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GadeProject
{
    internal class Map
    {

        private Tile[,] Maps;
        public Tile[,] Enemies;
        public Hero PLAYER;
        
            

            public Hero GetHero()
            {
                return PLAYER;
            }
            
            public Tile[,] MAPS
            {
                get { return Maps; }
                set { Maps = value; }
            }

        internal void TryMove(Character.Movement controls)
        {
            throw new NotImplementedException();
        }
    }
}
