﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GadeProject
{
    internal class Hero : Character
    {
        public Hero(int x, int y, TileType type, int Hp) : base (x, y, type)
        {
            int HP = Hp;
            int MaxHp = Hp;
            int damage = 2;
        }

        public override ReturnMove()
        {

        }
    }
}
