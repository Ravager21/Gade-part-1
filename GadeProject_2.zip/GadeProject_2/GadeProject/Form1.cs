namespace GadeProject
{
    public partial class Form1 : Form
    {
   
        GameEngine Engine = new GameEngine();
        
        
        
        public Form1()
        {
            InitializeComponent();
        }
        

        private void button2_Click(object sender, EventArgs e)
        {
            Engine.MovePlayer(Character.MovementEnum.Up);
            
            GameMap.Text = Engine.MAP.ToString();
            
        }
        

        private void RightBtn_Click(object sender, EventArgs e)
        {
            Engine.MovePlayer(Character.MovementEnum.Right);
            
            GameMap.Text = Engine.MAP.ToString();
        }

        private void LeftBtn_Click(object sender, EventArgs e)
        {
            Engine.MovePlayer(Character.MovementEnum.Left);
            
            GameMap.Text = Engine.MAP.ToString();
        }

        private void DownBtn_Click(object sender, EventArgs e)
        {
            Engine.MovePlayer(Character.MovementEnum.Down);

            GameMap.Text = Engine.MAP.ToString();
        }

        private void GameMap_Click(object sender, EventArgs e)
        {
            //GameMap.Text = Engine.MAP.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            GameMap.Text = GameEngine.MAP.mapContainer();
        }
    }

    
}