﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GadeProject
{
    internal class GameEngine 
    {
        public Label maplabel = new Label();
        private Map map;
        public Map MAP
        {
            get { return map; }
            set { map = value; }
        }
        public GameEngine()
        {
            MAP = new Map(10, 20, 10, 20, 5);
            
        }
        public bool MovePlayer(Character.MovementEnum direction)
        {
            Character.MovementEnum DIRECTION = MAP.getHero().ReturnMove(direction);
            if (DIRECTION == direction)
            {
                MAP.getHero().Move(direction);
                return true;
            }

            else

            {
                return false;
            }
        }
    }
}
