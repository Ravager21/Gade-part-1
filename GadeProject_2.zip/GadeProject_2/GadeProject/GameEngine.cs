﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GadeProject
{
    internal class GameEngine 
    {
        public Label maplabel = new Label();
        private Map map;
        public Map MAP
        {
            get { return map; }
            set { map = value; }
        }
        public GameEngine()
        {
            map = new Map(10, 20, 10, 20, 5, 4, 5);
            
        }
        public void MovePlayer(Character.Movement controls)
        {
            MAP.TryMove(controls);

        }
    }
}
