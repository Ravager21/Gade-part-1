﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GadeProject
{
    internal class SwampCreatures : Enemy
    {
        public SwampCreatures(int x, int y) : base (x, y, 1, TileType.Enemy, 10, 10, "SC")
        {
            

        }

        public override Movement ReturnMove(Movement movement)
        {
            int space = 0;
            int RandMovement = num.Next(5);
            Movement EnemyMove = (Movement)RandMovement;

            for(int i = 0; Vision.Count > i; i++)
            {
                if (Vision[i] is EmptyTile)
                {
                    space++;
                }

            }
            if(space == 0)
            {
                return Movement.NoMovement;
            }

            while(space > 0)
            {
                if (EnemyMove == Movement.Up)
                {
                    if ((!(this.Vision[0] is Character)) && (!(this.Vision[0] is Obstacle)))
                    {
                        return Movement.Up;
                    }

                }
                if (EnemyMove == Movement.Down)
                {
                    if ((!(this.Vision[1] is Character)) && (!(this.Vision[1] is Obstacle)))
                    {
                        return Movement.Down;
                    }
                }

                if (EnemyMove == Movement.Left)
                {
                    if ((!(this.Vision[2] is Character)) && (!(this.Vision[2] is Obstacle)))
                    {
                        return Movement.Left;
                    }
                }

                if (EnemyMove == Movement.Right)
                {
                    if ((!(this.Vision[3] is Character)) && (!(this.Vision[3] is Obstacle)))
                    {
                        return Movement.Right;
                    }
                }
                EnemyMove = (Movement)(num.Next(4) + 1);
            }
            return Movement.NoMovement;
        }
    }
}
