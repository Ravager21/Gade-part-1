﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GadeProject
{
    public abstract class Character : Tile
    {
        protected Character(int x, int y, TileType type) : base(x, y, type)
        {

        }

        protected int Hp { set; get; }
        protected int maxHp {set; get;}
        protected int Damage { set; get; }

        string[] TileArray = { "North", "South", "East", "West" };

        public enum Movement
        {
            NoMovement,
            Up,
            Down,
            Right,
            Left

        }

        override public virtual void Attack()
        {

        }

        public bool IsDead()
        {
            if(Hp == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public virtual bool CheckRange()
        {

        }
        
        public void Move(Movement move)
        {
            if(move == Movement.NoMovement)
            {
                this.x = 0;
            }
            else if(move == Movement.Up)
            {
                this.x++;
            }
            else if (move == Movement.Down)
            {
                this.x--;
            }
            else if(move == Movement.Right)
            {
                this.y++;
            }
            else if(move == Movement.Left)
            {
                this.y--;
            }
        }
        public abstract Movement ReturnMove(Movement move);

        protected List<Tile> vision = new List<Tile>();

        public List<Tile> Vision
        {
            get { return vision; }
            set { vision = value; }
        }
        
        public void setVision(Tile[,] Sight)
        {
            Vision.Clear();

            Vision.Add(Sight[x - 1, y]);
            Vision.Add(Sight[x + 1, y]);
            Vision.Add(Sight[x, y - 1]);
            Vision.Add(Sight[x, y + 1]);
        }

    }
}
